// Optional JavaScript for interaction can be added here.
console.log("Art Gallery site loaded");